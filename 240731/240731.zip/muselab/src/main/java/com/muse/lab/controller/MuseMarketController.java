package com.muse.lab.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.muse.lab.paging.Criteria;
import com.muse.lab.vo.MuseLabVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface MuseMarketController {
	
	// 관리자
	
	// 판매 요청 게시글 출력
	public String sellList(@ModelAttribute("MuseLabVO") MuseLabVO mlVO,Model m,Criteria criteria) throws Exception;
	
	// 판매 요청 게시글 세부 내용 출력
	public ModelAndView sellView(@RequestParam("market_id") String market_id,
			HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 판매 요청 게시글 등업 수정
	public ModelAndView statusMod(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception;
	
	// 사용자
	
	// 판매 게시 요청
	public String marketInsert(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response, Model m,MultipartHttpServletRequest mtf) throws Exception;

	// 판매 승인 게시글 출력
	public ModelAndView mkList(HttpServletRequest request,HttpServletResponse repsonse) throws Exception;
	
	// 판매 승인 게시글 세부 내용 출력
	public ModelAndView mkListView(@RequestParam("market_id") String market_id,
			HttpServletRequest request,HttpServletResponse repsonse) throws Exception;
	
	// 수량 수정
	public ModelAndView buyInsert(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception;
	
	// 결제하기 창 출력
	public ModelAndView buyList(@RequestParam("buyId") String buyId,
			HttpServletRequest request,HttpServletResponse repsonse) throws Exception;

	ModelAndView buyList(int buyId, HttpServletRequest request, HttpServletResponse response) throws Exception;
}

