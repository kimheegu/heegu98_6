package com.muse.lab.service;

import java.util.List;

import com.muse.lab.paging.Criteria;
import com.muse.lab.vo.MuseLabVO;

public interface MuseMarketService {

	// 관리자
	
	// 판매 요청 게시글 출력
	public List<MuseLabVO> listCriteria(Criteria criteria) throws Exception;	

	// 판매 요청 게시글 세부 내용 출력
  	public List sellView(String market_id) throws Exception;
  	
  	// 전체 게시글 개수
  	public int count(Criteria criteria) throws Exception;
  	
  	// 판매 게시글 등업 수정
  	public int statusMod(MuseLabVO mlVO) throws Exception;
  	
  	
  	// 사용자
	
	// 판매 게시 요청
	public int marketInsert(MuseLabVO mlVO) throws Exception;
	
	// 판매 승인 게시글 출력
	public List mkList() throws Exception;
	
	// 판매 승인 게시글 세부 내용 출력
	public List mkListView(String market_id) throws Exception;
	
	// 구매 수량,가격
	public int buyInsert(MuseLabVO mlVO) throws Exception;
	
	// 주문 정보 출력
	public List buyList(int buyId) throws Exception;
}
