package com.muse.lab.main;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component("mlVO")
public class MuseLabVO {
	// user
	private String userId;
	private String userPwd;
	private String userPhone;
	private String userEmail;
	private String userNickname;
	private String userProfile;
	private String userInfo;
	private String userAddress;
	private String userGrade;
	
	// music
	private int musicId;
	private String musicTitle;
	private String musicInfo;
	private String musicGenre;
	private String musicAlbum;
	private Date musicDate;
	private String musicImage;
	private int musicViews;
	private int musicLike;
	
	// music comment
	private int musicCommentId;
	private String musicCommentContent;
	private Date musicCommentDate;
	
	// music like
	private int musicLikeId;
	
	// playlist
	private int playlistId;
	private String playlistFolder;
	
	// community
	private int communityId;
	private String communityCategory;
	private String communityTitle;
	private String communityContent;
	private Date communityDate;
	private String communityImage1;
	private String communityImage2;
	private String communityImage3;
	private String communityImage4;
	private String communityImage5;
	private String communityViews;
	private String communityLike;
	
	// comm comment
	private int commCommentId;
	private String commCommentContent;
	private Date commCommentDate;
	
	// comm like
	private int commLikeID;
	
	// market
	private List<MultipartFile> files;
	private int marketId;
	private String marketTitle;
	private String marketContent;
	private String marketImage1;
	private String marketImage2;
	private String marketImage3;
	private String marketImage4;
	private String marketImage5;
	private int marketPrice;
	private String marketCategory;
	private int marketViews;
	private String marketDescription;
	private int marketStock;
	private String marketStock1;
	private String marketStatus;
	
	// market comment
	private int mkCommentId;
	private String mkCommentContent;
	private Date mkCommentDate;
	
	// market like
	private int mkLikeId;
	
	// user msg
	private int userMsgId;
	private String userMsgTitle;
	private String userMsgContent;
	private Date userMsgDate;
	
	// notice
	private int noticeId;
	
	// operation
	private int operationId;
	
	// ad
	private int adId;
	private String adTitle;
	private Date adStart;
	private Date adEnd;
	private String adImage;
	private String adMemo;
	
	// cart
	private int cartId;
	private int cartCount;
	
	// buy
	private int buyId;
	private String orderId;
	private int buyCount;
	private String buyStatus;
	private String buyPackageCom;
	private String buyPackageNum;
	
	// admin
	private String adminId;
	private String adminPwd;
	private String adminName;
	
	// file
	private String filename;
	private String filepath;
} 
