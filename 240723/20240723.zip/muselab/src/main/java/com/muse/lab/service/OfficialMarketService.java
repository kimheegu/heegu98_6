package com.muse.lab.service;

public interface OfficialMarketService {

}
