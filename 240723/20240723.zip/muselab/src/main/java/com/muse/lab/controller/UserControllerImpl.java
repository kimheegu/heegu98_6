package com.muse.lab.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.muse.lab.main.MuseLabVO;
import com.muse.lab.service.UserService;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("userController")
public class UserControllerImpl implements UserController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private MuseLabVO mlVO;
	
	// 프로퍼티파일로부터 저장 경로 참조
	@Value("${market.imgdir}")
	String fdir;
	
	// 회원 메인 페이지
	@GetMapping("/user/userMain.do")
	public ModelAndView userMain(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("/user/userMain");
		return mav;
	}
	
	// 회원 로그인
	@Override
	@PostMapping("/user/userLogin.do")
	public ModelAndView userLogin(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rAttr,BindingResult userloginResult) throws Exception {
		ModelAndView mav = new ModelAndView();
		mlVO = userService.userLogin(mlVO);
		if(mlVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", mlVO);
			session.setAttribute("userId", mlVO.getUserId());
			session.setAttribute("isLogOn", true);

			String action = (String) session.getAttribute("action");
			session.removeAttribute("action");

			if (action != null) {
				mav.setViewName("redirect:" + action);
			} else {
				mav.setViewName("redirect:/user/userMain.do");
				mav.addObject("userId",mlVO.getUserId());
			}
		} else {
			rAttr.addAttribute("result", "loginFailed");
			mav.setViewName("redirect:/user/loginForm.do");
		}
		return mav;
	}
	
	// 로그아웃
	@Override
	@GetMapping("/user/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		session.setAttribute("isLogOn", false);

		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/user/userMain.do");
		return mav;
	}
	
	//뮤즈마켓 메인페이지
    @GetMapping("/user/MuseMarket.do")
    public String MuseMarket() {
        return "user/MuseMarket"; 
    }
    
    //뮤즈마켓 판매 게시 요청
    @Override
    @PostMapping("/user/marketInsert.do")
    public String marketInsert(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response, Model m,MultipartHttpServletRequest mtf) throws Exception {
    	// 각 파일 이름을 저장할 리스트
    	List<String> list = new ArrayList<>();
    	List<MultipartFile> img = mtf.getFiles("file");
    	// 각 파일 이름과 저장된 물리적인 경로를 저장할 맵
    	Map<String, String> paths = new HashMap<>();
    	// 파일 개수가 3개 이하일 때만 처리
    	if(img != null && img.size() <= 5) {
    		for(int i = 0; i<img.size(); i++) {
    			String fieldName = "marketImage"+(i+1); // 필드 이름 생성
    			MultipartFile file = img.get(i);
    			String fileName;
    			
    			// 파일이 존재하는 경우 실제 파일 이름 사용, 없는 경우 "-"으로 설정
    			if(file.isEmpty()) {
    				fileName = "-";
    			}else {
    				fileName = file.getOriginalFilename();
    				switch(fieldName) {
    				case "marketImage1":
    					mlVO.setMarketImage1(fileName);
    				case "marketImage2":
    					mlVO.setMarketImage2(fileName);
    				case "marketImage3":
    					mlVO.setMarketImage3(fileName);
    				case "marketImage4":
    					mlVO.setMarketImage4(fileName);
    				case "marketImage5":
    					mlVO.setMarketImage5(fileName);
    				break;	
    				}
    				try {
    					ServletContext application = request.getSession().getServletContext();
    					String path = application.getRealPath(fdir); //실제 물리적인 경로
    					// 파일 경로와 파일명을 올바르게 합쳐서 파일 객체 생성
    					File targetFile = new File(path, fileName);
    					
    					// 파일 저장
    					file.transferTo(targetFile);
    					
    					// 파일이 정상적으로 저장된 경울 경로를 맵에 저장
    					paths.put(fieldName, targetFile.getAbsolutePath());
    				}catch(IOException e) {
    					e.printStackTrace();
    					// 파일 저장 중 오류 발생 시 처리할 내용
    				}
    			}
    		}
    	}

		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("user_id");
		
		int result = 0;
		result =userService.marketInsert(mlVO);
		return "user/MuseMarket";
    }
		
	// form으로 끝나는 파일 실행시
	@GetMapping("/*/*Form.do")
	private ModelAndView form(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		HttpSession session = request.getSession();
		session.setAttribute("action", action);

		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}
}
