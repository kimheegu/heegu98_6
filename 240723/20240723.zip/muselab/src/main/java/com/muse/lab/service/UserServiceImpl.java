package com.muse.lab.service;

import java.io.File;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.muse.lab.dao.UserDAO;
import com.muse.lab.main.MuseLabVO;



@Service("userService")
@Transactional(propagation = Propagation.REQUIRED)
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDAO userDAO;

	// 회원 로그인
	@Override
	public MuseLabVO userLogin(MuseLabVO mlVO) throws Exception {
		return userDAO.userLogin(mlVO);
	}
	
	// 판매 게시 요청
	@Override
	public int marketInsert(MuseLabVO mlVO) throws Exception {
		return userDAO.marketInsert(mlVO);
	}
	
}
