package com.muse.lab.service;

import org.springframework.web.multipart.MultipartFile;

import com.muse.lab.main.MuseLabVO;

public interface UserService {
	// 회원 로그인
	public MuseLabVO userLogin(MuseLabVO mlVO) throws Exception;
	
	// 판매 게시 요청
	public int marketInsert(MuseLabVO mlVO) throws Exception;
}
