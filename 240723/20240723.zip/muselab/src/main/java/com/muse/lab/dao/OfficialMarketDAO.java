package com.muse.lab.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository("omkDAO")
public interface OfficialMarketDAO {

}
