package com.muse.lab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.muse.lab.main.MuseLabVO;
import com.muse.lab.service.OfficialMarketService;

@Controller("omkController")
public class OfficialMarketControllerImpl implements OfficialMarkerController {

	@Autowired
	private OfficialMarketService omkService;
	
	@Autowired
	private MuseLabVO muselabVO;
}
