package com.muse.lab.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.muse.lab.dao.UserDAO;
import com.muse.lab.main.MuseLabVO;
import com.muse.lab.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("userController")
public class UserControllerImpl implements UserController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private MuseLabVO mlVO;
	
	// 프로퍼티파일로부터 저장 경로 참조
	@Value("${market.imgdir}")
	String fdir;
	
	// 회원 메인 페이지
	@GetMapping("/user/userMain.do")
	public ModelAndView userMain(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("/user/userMain");
		return mav;
	}
	
	// 회원 로그인
	@Override
	@PostMapping("/user/userLogin.do")
	public ModelAndView userLogin(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rAttr,BindingResult userloginResult) throws Exception {
		ModelAndView mav = new ModelAndView();
		mlVO = userService.userLogin(mlVO);
		if(mlVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", mlVO);
			session.setAttribute("userId", mlVO.getUserId());
			session.setAttribute("isLogOn", true);

			String action = (String) session.getAttribute("action");
			session.removeAttribute("action");

			if (action != null) {
				mav.setViewName("redirect:" + action);
			} else {
				mav.setViewName("redirect:/user/userMain.do");
				mav.addObject("userId",mlVO.getUserId());
			}
		} else {
			rAttr.addAttribute("result", "loginFailed");
			mav.setViewName("redirect:/user/loginForm.do");
		}
		return mav;
	}
	
	// 로그아웃
	@Override
	@GetMapping("/user/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		session.setAttribute("isLogOn", false);

		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/user/userMain.do");
		return mav;
	}
	
	//뮤즈마켓 메인페이지
    @GetMapping("/user/MuseMarket.do")
    public String MuseMarket() {
        return "user/MuseMarket"; 
    }
    
    //뮤즈마켓 판매 게시 요청
    @Override
    @PostMapping("/user/marketInsert.do")
    public ModelAndView marketInsert(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response, Model m, @RequestParam("file") MultipartFile file) throws Exception {
    	// 저장 파일 객체 생성
    	File dest = new File(fdir+"/"+file.getOriginalFilename());
		
    	// 파일 저장
		file.transferTo(dest);
		
		// News 객체에 파일 이름 저장
		mlVO.setMarketImage1("/images/"+dest.getName());
		userService.marketInsert(mlVO);
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("user_id");
		
		int result = 0;
		result =userService.marketInsert(mlVO);
		ModelAndView mav = new ModelAndView("redirect:/user/MuseMarket.do");
		mav.addObject("user_id", userId);
		return mav;
    }
		
	// form으로 끝나는 파일 실행시
	@GetMapping("/*/*Form.do")
	private ModelAndView form(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		HttpSession session = request.getSession();
		session.setAttribute("action", action);

		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}
}
