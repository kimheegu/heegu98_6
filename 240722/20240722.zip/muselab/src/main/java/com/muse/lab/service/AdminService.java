package com.muse.lab.service;

import java.util.List;

import com.muse.lab.main.MuseLabVO;

public interface AdminService {
	
	//관리자 로그인
    public MuseLabVO adminLogin(MuseLabVO muselabVO) throws Exception;
    
    // 관리자 메인 (임시)
    public List adminMain(String adminId) throws Exception;
}
