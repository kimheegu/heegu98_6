package com.muse.lab.controller;

import java.util.ArrayList;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.muse.lab.main.MuseLabVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface UserController {
	// 회원 로그인
	public ModelAndView userLogin(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes rAttr,BindingResult userloginResult) throws Exception;
	
	// 로그아웃
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	// 판매 게시 요청
	public ModelAndView marketInsert(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response, Model m, @RequestParam("file") MultipartFile file) throws Exception;
}
