package com.muse.lab.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.muse.lab.main.MuseLabVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface AdminController {
	
	//관리자 로그인
	public ModelAndView adminLogin(@ModelAttribute("muselabVO") MuseLabVO muselabVO, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes rAttr) throws Exception;

	//관리자 로그아웃
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
