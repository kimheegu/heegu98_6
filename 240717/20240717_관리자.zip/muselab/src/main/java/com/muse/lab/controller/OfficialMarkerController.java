package com.muse.lab.controller;

public interface OfficialMarkerController {

}
