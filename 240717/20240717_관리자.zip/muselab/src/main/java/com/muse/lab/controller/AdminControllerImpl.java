package com.muse.lab.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.muse.lab.main.MuseLabVO;
import com.muse.lab.service.AdminService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("adminController")
public class AdminControllerImpl implements AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private MuseLabVO muselabVO;
	
	//관리자 로그인
	@Override
	@PostMapping("/admin/adminLogin.do")
	public ModelAndView adminLogin(@ModelAttribute("muselabVO") MuseLabVO muselabVO, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes rAttr) throws Exception {
		ModelAndView mav = new ModelAndView();
		muselabVO = adminService.adminLogin(muselabVO);
		if (muselabVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("admin", muselabVO);
			session.setAttribute("adminId", muselabVO.getAdminId()); 
			session.setAttribute("isLogOn", true);

			String action = (String) session.getAttribute("action");
			session.removeAttribute("action");

			if (action != null) {
				mav.setViewName("redirect:" + action);
			} else {
				mav.setViewName("redirect:/admin/adminMain.do");
				mav.addObject("adminId",muselabVO.getAdminId());
			}
		} else {
			rAttr.addAttribute("result", "loginFailed");
			mav.setViewName("redirect:/admin/adloginForm.do");
		}
		return mav;
	}
	
	//관리자 로그아웃
	@Override
	@GetMapping("/admin/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.removeAttribute("muselabVO");
		session.removeAttribute("adminId");
		session.removeAttribute("admin");
		session.setAttribute("isLogOn", false);

		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/admin/adloginForm.do");
		return mav;
	}
	
    @GetMapping("/admin/adminMain.do")
    public String main() {
        return "admin/adminMain"; 
    }
    
    @GetMapping("/admin/omkMain.do")
    public String omkMain() {
        return "admin/omkMain"; 
    }
    
    @GetMapping("/admin/omkInput.do")
    public String omkInput() {
        return "admin/omkInput"; 
    }


	@GetMapping("/*/*Form.do")
	private ModelAndView form(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		HttpSession session = request.getSession();
		session.setAttribute("action", action);

		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}
}
