package com.muse.lab.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.muse.lab.dao.OfficialMarketDAO;

@Service("omkService")
public class OfficialMarketServiceImpl implements OfficialMarketService {

	@Autowired
	private OfficialMarketDAO omkDAO;
	
}
