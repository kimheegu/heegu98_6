package com.muse.lab.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.muse.lab.main.MuseLabVO;


@Mapper
@Repository("adminDAO")
public interface AdminDAO {

	// 관리자 로그인
    public MuseLabVO adminLogin(MuseLabVO muselabVO) throws DataAccessException;
    
    // 관리자 메인페이지 (임시)
    public List<MuseLabVO> adminMain(String adminId) throws DataAccessException;
}
