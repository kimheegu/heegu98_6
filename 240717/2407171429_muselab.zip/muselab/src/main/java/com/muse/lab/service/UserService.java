package com.muse.lab.service;

import com.muse.lab.vo.MuseLabVO;

public interface UserService {
	// 회원 로그인
	public MuseLabVO userLogin(MuseLabVO mlVO) throws Exception;
}
