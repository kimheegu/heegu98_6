package com.muse.lab.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.muse.lab.dao.UserDAO;
import com.muse.lab.vo.MuseLabVO;

@Service("userService")
@Transactional(propagation = Propagation.REQUIRED)
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDAO userDAO;

	@Override
	public MuseLabVO userLogin(MuseLabVO mlVO) throws Exception {
		return userDAO.userLogin(mlVO);
	}
	
}
