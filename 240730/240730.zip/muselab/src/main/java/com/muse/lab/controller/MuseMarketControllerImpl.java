package com.muse.lab.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.muse.lab.paging.Criteria;
import com.muse.lab.paging.PageMaker;
import com.muse.lab.service.MuseMarketService;
import com.muse.lab.vo.MuseLabVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("omkController")
@RequestMapping(value = "/market")
public class MuseMarketControllerImpl implements MuseMarketController {
	@Autowired
	private MuseLabVO muselabVO;
	
	@Autowired
	private MuseMarketService museMkservice;
	
	// 프로퍼티파일로부터 저장 경로 참조
	@Value("${market.imgdir}")
	String fdir;


	
	// 관리자
	
	// 판매 요청 게시글 출력
	@Override
	@GetMapping("/adminMkMainForm.do")
	public String sellList(@ModelAttribute("MuseLabVO") MuseLabVO mlVO,Model m,Criteria criteria) throws Exception {
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCriteria(criteria);
		pageMaker.setTotalCount(museMkservice.count(criteria));
		
		m.addAttribute("sellList",museMkservice.listCriteria(criteria));
		m.addAttribute("pageMaker",pageMaker);
		return "/market/adminMkMainForm";
	}
	
	// 판매 요청 게시글 세부 내용 출력
	@Override
	@GetMapping("/sellView.do")
	public ModelAndView sellView(@RequestParam("market_id") String market_id,
			 HttpServletRequest request, HttpServletResponse response) throws Exception {
		List sellList = museMkservice.sellView(market_id);
		ModelAndView mav = new ModelAndView("/market/adminSellView");
		mav.addObject("sellList",sellList);
		return mav;
	}
	
	// 판매 요청 게시글 등업 수정
	@Override
	@PostMapping("/statusMod.do")
	public ModelAndView statusMod(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String market_Id = (String) session.getAttribute("marketId");
		int result = 0;
		result = museMkservice.statusMod(mlVO);
		System.out.println(museMkservice.statusMod(mlVO));
		
		ModelAndView mav = new ModelAndView("redirect:/market/adminMkMainForm.do");
		mav.addObject("marketId",market_Id);
		return mav;
	}
	
	
	// 사용자
	
	// 판매 승인 게시글 출력 (뮤즈마켓 메인페이지)
		@Override
		@GetMapping("/MuseMarket.do")
		public ModelAndView mkList(HttpServletRequest request,HttpServletResponse repsonse) throws Exception {
			List mkList = museMkservice.mkList();
			ModelAndView mav = new ModelAndView("/market/MuseMarket");
			mav.addObject("mkList",mkList);
			return mav;
		}
		
	    //뮤즈마켓 판매 게시 요청
	    @Override
	    @PostMapping("/marketInsert.do")
	    public String marketInsert(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
				HttpServletResponse response, Model m,MultipartHttpServletRequest mtf) throws Exception {
	    	// 각 파일 이름을 저장할 리스트
	    	List<String> list = new ArrayList<>();
	    	List<MultipartFile> img = mtf.getFiles("file");
	    	// 각 파일 이름과 저장된 물리적인 경로를 저장할 맵
	    	Map<String, String> paths = new HashMap<>();
	    	// 파일 개수가 5개 이하일 때만 처리
	    	if(img != null && img.size() <= 5) {
	    		for(int i = 0; i<img.size(); i++) {
	    			String fieldName = "marketImage"+(i+1); // 필드 이름 생성
	    			MultipartFile file = img.get(i);
	    			String fileName;
	    			UUID uuid = UUID.randomUUID();
	    			
	    			// 파일이 존재하는 경우 실제 파일 이름 사용, 없는 경우 "-"으로 설정
	    			if(file.isEmpty()) {
	    				fileName = "-";
	    			}else {
	    				fileName = file.getOriginalFilename();
	    				String fileName1 = uuid.toString() + fileName;
	    				switch(fieldName) {
	    				case "marketImage1":
	    					mlVO.setMarketImage1(fileName1);
	    				case "marketImage2":
	    					mlVO.setMarketImage2(fileName1);
	    				case "marketImage3":
	    					mlVO.setMarketImage3(fileName1);
	    				case "marketImage4":
	    					mlVO.setMarketImage4(fileName1);
	    				case "marketImage5":
	    					mlVO.setMarketImage5(fileName1);
	    				break;	
	    				}
	    				try {
	    					String path = fdir; //실제 물리적인 경로
	    					// 파일 경로와 파일명을 올바르게 합쳐서 파일 객체 생성
	    					File targetFile = new File(path, fileName1);
	    					
	    					// 파일 저장
	    					file.transferTo(targetFile);
	    					
	    					// 파일이 정상적으로 저장된 경울 경로를 맵에 저장
	    					paths.put(fieldName, targetFile.getAbsolutePath());
	    				}catch(IOException e) {
	    					e.printStackTrace();
	    					// 파일 저장 중 오류 발생 시 처리할 내용
	    				}
	    			}
	    		}
	    	}

			request.setCharacterEncoding("utf-8");
			HttpSession session = request.getSession();
			String userId = (String) session.getAttribute("user_id");
			
			int result = 0;
			result = museMkservice.marketInsert(mlVO);
			return "market/MuseMarket";
	    }
	    
	    // 판매 승인 게시글 세부 내용 출력
	    @Override
	    @GetMapping("/sell.do")
	    public ModelAndView mkListView(@RequestParam("market_id") String market_id,
				HttpServletRequest request,HttpServletResponse repsonse) throws Exception {
			List mkList = museMkservice.mkListView(market_id);
			ModelAndView mav = new ModelAndView("/market/sell");
			mav.addObject("mkList",mkList);
			return mav;
	    }
	    
	    // 구매 내역
	    @Override
	    @PostMapping("/buyInsert.do")
	    public ModelAndView buyInsert(@ModelAttribute("MuseLabVO") MuseLabVO mlVO, HttpServletRequest request,
	            HttpServletResponse response) throws Exception {
	    	HttpSession session = request.getSession();
	    	MuseLabVO user = (MuseLabVO)session.getAttribute("user");
	    	String userId = user.getUserId();
	    	mlVO.setUserId(userId);
	    	session.setAttribute("buyList", mlVO);
	        int result = 0;
	        result = museMkservice.buyInsert(mlVO);
			ModelAndView mav = new ModelAndView("redirect:/market/BuyForm.do");
			mav.addObject("userId",userId);
	        return mav;
	    }

	    
	    // 구매하기
		@Override
		@GetMapping("/BuyForm.do")
		public ModelAndView buyList(@RequestParam("userId") String userId,
		        HttpServletRequest request, HttpServletResponse response) throws Exception {
		    HttpSession session = request.getSession();
		    MuseLabVO buy = (MuseLabVO)session.getAttribute("buyList");
		    String user_id = buy.getUserId();
	    	System.out.println(userId);

		    List buyList = museMkservice.buyList(user_id);
		    ModelAndView mav = new ModelAndView("/market/BuyForm");
		    mav.addObject("buyList", buyList);
		    return mav;
		}
		
		// form으로 끝나는 파일 실행시
		@GetMapping("/*Form.do")
		private ModelAndView form(@RequestParam(value = "result", required = false) String result,
				@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			String viewName = (String) request.getAttribute("viewName");
			HttpSession session = request.getSession();
			session.setAttribute("action", action);

			ModelAndView mav = new ModelAndView();
			mav.addObject("result", result);
			mav.setViewName(viewName);
			return mav;
		}

}
