package com.muse.lab.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.muse.lab.paging.Criteria;
import com.muse.lab.vo.MuseLabVO;


@Mapper
@Repository("museMarketDAO")
public interface MuseMarketDAO {
	
	// 관리자
	
	// 전체 판매 요청 게시글 출력
	public List<MuseLabVO> listCriteria(Criteria criteria) throws DataAccessException;
	
	// 판매 게시글 개수
	public int count(Criteria criteria) throws Exception;
	
	// 판매 요청 게시글 세부 정보 출력
	public List<MuseLabVO> sellView(String market_id) throws DataAccessException;
	
	// 판매 게시글 등업 수정
	public int statusMod(MuseLabVO mlVO) throws DataAccessException;
	
	
	// 사용자
	
	// 판매 게시 요청
	public int marketInsert(MuseLabVO mlVO) throws DataAccessException;
	
	// 판매 승인 게시글 출력
	public List<MuseLabVO> mkList() throws DataAccessException;
	
	// 판매 승인 게시글 세부 내용 출력
	public List<MuseLabVO> mkListView(String market_id) throws DataAccessException;
	
	// 구매 내역
	public int buyInsert(MuseLabVO mlVO) throws DataAccessException;
	
	// 결제하기 창 출력
	public List<MuseLabVO> buyList(int buyId) throws DataAccessException;
}
