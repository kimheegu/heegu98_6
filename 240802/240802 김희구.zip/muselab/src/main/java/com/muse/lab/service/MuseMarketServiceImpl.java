package com.muse.lab.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.muse.lab.dao.MuseMarketDAO;
import com.muse.lab.paging.Criteria;
import com.muse.lab.vo.MuseLabVO;

@Service("MarketService")
public class MuseMarketServiceImpl implements MuseMarketService {
	@Autowired
	private MuseMarketDAO museMkdao;
	
	// 관리자
	
	// 판매 요청 게시글 출력
	@Override
	public List<MuseLabVO> listCriteria(Criteria criteria) throws Exception {
		return museMkdao.listCriteria(criteria);
	}
	
	// 전체 판매 요청 게시글 개수
	@Override
	public int count(Criteria criteria) throws Exception {
		return museMkdao.count(criteria);
	}
	
	// 전체 판매 게시글 세부 내용 출력
	@Override
	public List sellView(String market_id) throws Exception {
		List sellList = null;
		sellList = museMkdao.sellView(market_id);
		return sellList;
	}
	
	// 판매 게시글 등업 수정
	public int statusMod(MuseLabVO mlVO) throws Exception {
		return museMkdao.statusMod(mlVO);
	}
	
	
	// 사용자
	
	// 판매 게시 요청
	@Override
	public int marketInsert(MuseLabVO mlVO) throws Exception {
		return museMkdao.marketInsert(mlVO);
	}
	
	// 판매 승인 게시글 출력
	@Override
	public List mkList() throws Exception {
		List mkList = null;
		mkList = museMkdao.mkList();
		return mkList;
	}
	
	// 판매 승인 게시글 세부 내용 출력
	public List mkListView(String market_id) throws Exception {
		List mkList = null;
		mkList = museMkdao.mkListView(market_id);
		return mkList;
	}	
	
	// 구매 수량,가격
	public int buyInsert(MuseLabVO mlVO) throws Exception {
		return museMkdao.buyInsert(mlVO);
	}
	
	// 주문 정보 출력
	public List buyList(int buyId) throws Exception {
		List buyList = null;
		buyList = museMkdao.buyList(buyId);
		return buyList;
	}
}
