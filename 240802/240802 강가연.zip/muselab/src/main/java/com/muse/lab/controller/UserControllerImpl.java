package com.muse.lab.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.muse.lab.service.UserService;
import com.muse.lab.vo.MuseLabVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller("userController")
@RequestMapping(value = "/user")
public class UserControllerImpl implements UserController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private MuseLabVO mlVO;
	
	// 유저 프로필 저장 경로
	@Value("${user.imgdir}")
	String udir;
	
	// 회원 메인페이지
	@GetMapping("/userMain.do")
	public ModelAndView userMain(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("/user/userMain");
		return mav;
	}
	
	// 정보 수정 페이지
	@GetMapping("/userModForm.do")
	public ModelAndView userModForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		String access_token = (String)session.getAttribute("accessToken");
		MuseLabVO user = (MuseLabVO)session.getAttribute("user");
		String userid = user.getUserId();
		mlVO.setUserId(userid);

		// 토큰값 유무로 카카오 가입 유저인지 아닌지 판별
		if(access_token != null) {
			MuseLabVO userInfo = userService.getUserInfo(access_token);
			String kakaoid = userInfo.getKakaoId();
			mlVO.setKakaoId(kakaoid);
			
			List userList = userService.userInfo(kakaoid);
			ModelAndView mav = new ModelAndView("/user/userModForm");
			mav.addObject("userList",userList);
			return mav;
		}
		
		List userList = userService.userInfo(userid);
		ModelAndView mav = new ModelAndView("/user/userModForm");
		mav.addObject("userList",userList);
		return mav;
	}
	
	// 회원 로그인
	@Override
	@PostMapping("/userLogin.do")
	public ModelAndView userLogin(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rAttr) throws Exception {
		ModelAndView mav = new ModelAndView();
		mlVO = userService.userLogin(mlVO);
		if(mlVO != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", mlVO);
			session.setAttribute("isLogOn", true);

			String action = (String) session.getAttribute("action");
			session.removeAttribute("action");

			if (action != null) {
				mav.setViewName("redirect:" + action);
			} else {
				mav.setViewName("redirect:/user/userMain.do");
				mav.addObject("userId", mlVO.getUserId());
			}
		} else {
			rAttr.addAttribute("result", "loginFailed");
			mav.setViewName("redirect:/user/loginForm.do");
		}
		return mav;
	}
	
	// 로그아웃
	@Override
	@GetMapping("/logout.do")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		session.removeAttribute("userId");
		session.removeAttribute("user");
		session.setAttribute("isLogOn", false);
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:/user/userMain.do");
		
		String access_token = (String)session.getAttribute("accessToken");
		
		if(access_token != null && !"".equals(access_token)){
			userService.kakaoLogout(access_token);
			
			session.removeAttribute("accessToken");
			session.removeAttribute("kakaoId");
			return mav;
		}
		
		return mav;
	}
	
	//카카오 로그인
	@Override
	@GetMapping("/kakaoLogin")
	public ModelAndView kakaoLogin(@RequestParam(value = "code", required = false) String code, HttpServletRequest request,  HttpServletResponse response, RedirectAttributes rAttr) throws IOException {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		
		System.out.println("#####authorize_code##### : [" + code +"]");
		
		// 카카오 code 보내서 토근 얻기
		String accessToken = userService.getAccessToken(code);
		System.out.println("#####accessToken##### : [" + accessToken +"]");
		
		session.setAttribute("accessToken", accessToken);
		
		// 토큰을 이용해 카카오 쪽에서 사용자 정보 가져오기
		MuseLabVO userInfo = userService.getUserInfo(accessToken);
		
		// 세션 형성 + request 내장 객체 가져오기
		session = request.getSession();
		
		// 세션에 담기
		if(userInfo.getKakaoId() != null) {
			session.setAttribute("user", mlVO);
			session.setAttribute("isLogOn", true);
			
			session.setAttribute("kakaoId", userInfo.getKakaoId());
			session.setAttribute("KakaoName", userInfo.getKakaoName());
			session.setAttribute("KakaoNickname", userInfo.getKakaoNickname());
			session.setAttribute("kakaoEmail", userInfo.getKakaoEmail());
			session.setAttribute("kakaoPhone", userInfo.getKakaoPhone());
			
			mav.addObject("kakaoId", userInfo.getKakaoId());
			mav.setViewName("redirect:/user/kakaoCheck.do");
			return mav;
		}
		mav.setViewName("redirect:/user/userMain.do");
		return mav;
	}
	
	// 카카오 회원가입
	@Override
	@GetMapping("/kakaoJoin.do")
	public ModelAndView kakaoJoin(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("--------------------카카오 회원 가입 진행--------------------");
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		request.setCharacterEncoding("utf-8");
		String access_token = (String)session.getAttribute("accessToken");
		
		MuseLabVO userInfo = userService.getUserInfo(access_token);
		
		int result = 0;
		result = userService.kakaoJoin(userInfo);
		
		mav.setViewName("redirect:/user/userMain.do");
		return mav;
	}
	
	
	// 카카오 회원 중복 확인
	@ResponseBody
	@GetMapping("/kakaoCheck.do")
	public ModelAndView kakaoCheck(@RequestParam(value = "kakaoId", required = false) Long kakaoId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("--------------------카카오 회원 중복 확인--------------------");
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		request.setCharacterEncoding("utf-8");
		String kakaoid = (String)session.getAttribute("kakaoId");
		String access_token = (String)session.getAttribute("accessToken");
		
		int result = userService.kakaoCheck(kakaoid);
		
		
		if(result == 0) {
			System.out.println("회원 정보 없음 : " + access_token);
			mav.setViewName("redirect:/user/kakaoJoin.do");
			return mav;
		}
		else if(result == 1) {
			System.out.println("회원 정보 있음 : " + kakaoid);
			mav.setViewName("redirect:/user/userMain.do");
			mav.addObject("userId", kakaoid);
			return mav;
		}
		
		mav.setViewName("redirect:/user/userMain.do");
		return mav;
	}
	
	// 회원가입
	@Override
	@PostMapping("/userJoin.do")
	public ModelAndView userJoin(@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		request.setCharacterEncoding("utf-8");
		String userid = request.getParameter("userId");
		HttpSession session = request.getSession();
		
		int result = 0;
		result = userService.userJoin(mlVO);
		mav.addObject("userId", userid);
		mav.setViewName("redirect:/user/userJoinComplete.do");
		return mav;
	}

	// 회원가입 확인
	@Override
	@GetMapping("/userJoinComplete.do")
	public ModelAndView userJoinComplete(@RequestParam("userId") String userId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		List userList = userService.userJoinComplete(userId);
		
		ModelAndView mav = new ModelAndView("/user/userJoinComplete");
		mav.addObject("userList",userList);
		return mav;
	}

	// 아이디 중복 확인
	@ResponseBody
	@PostMapping("/idCheck.do")
	public int idCheck(@RequestParam("userId") String userId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		int result = userService.idCheck(userId);
		return result;
	}
	
	// 닉네임 중복 확인
	@ResponseBody
	@PostMapping("/nicknameCheck.do")
	public int nicknameCheck(@RequestParam("userNickname") String userNickname, HttpServletRequest request, HttpServletResponse response) throws Exception {
		int result = userService.nicknameCheck(userNickname);
		return result;
	}

	// 회원 정보 가져오기
	@Override
	@GetMapping("/userInfo.do")
	public ModelAndView userInfo(@RequestParam(value = "userId", required = false) String userId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		MuseLabVO user = (MuseLabVO) session.getAttribute("user");
		String access_token = (String)session.getAttribute("accessToken");
		
		// 유저 정보 가져오기
		String userid = user.getUserId();
		mlVO.setUserId(userid);
		
		// 토큰값 유무로 카카오 가입 유저인지 아닌지 판별
		if(access_token != null) {
			MuseLabVO userInfo = userService.getUserInfo(access_token);
			String kakaoid = userInfo.getKakaoId();
			mlVO.setKakaoId(kakaoid);
			
			List userList = userService.userInfo(kakaoid);
			ModelAndView mav = new ModelAndView("/user/myPage");
			mav.addObject("userList",userList);
			return mav;
			
		}
		List userList = userService.userInfo(userid);
		
		ModelAndView mav = new ModelAndView("/user/myPage");
		mav.addObject("userList",userList);
		return mav;
	}
	
	// 회원 정보 수정
	@Override
	@PostMapping("/userInfoMod.do")
	public ModelAndView userInfoMod (@ModelAttribute("mlVO") MuseLabVO mlVO, HttpServletRequest request, HttpServletResponse response) throws Exception{
		HttpSession session = request.getSession();
		request.setCharacterEncoding("utf-8");
		MuseLabVO user = (MuseLabVO) session.getAttribute("user");
		String access_token = (String)session.getAttribute("accessToken");
		
		// 일반 가입 유저 정보 가져오기
		String userid = user.getUserId();
		mlVO.setUserId(userid);
		
		// 토큰값 유무로 카카오 가입 유저인지 아닌지 판별
		if(access_token != null) {
			MuseLabVO userInfo = userService.getUserInfo(access_token);
			String kakaoid = userInfo.getKakaoId();
			mlVO.setUserId(kakaoid);
			
			int result = 0;
			result = userService.userInfoMod(mlVO);
			
			ModelAndView mav = new ModelAndView("redirect:/user/userInfo.do");
			return mav;
		}
		
		int result = 0;
		result = userService.userInfoMod(mlVO);
		
		ModelAndView mav = new ModelAndView("redirect:/user/userInfo.do");
		mav.addObject("userId",userid);
		return mav;
	}
	
	// 회원 프로필 사진 수정
	@Override
	@PostMapping("/userProfileMod.do")
	public ModelAndView userProfileMod(@RequestParam("userProfile") MultipartFile userProfile, HttpServletRequest request, HttpServletResponse response, Model m, MultipartHttpServletRequest mtf) throws Exception {
		HttpSession session = request.getSession();
		request.setCharacterEncoding("utf-8");
		MuseLabVO user = (MuseLabVO) session.getAttribute("user");
		String access_token = (String)session.getAttribute("accessToken");
		
		MultipartFile profile = mtf.getFile("userProfile");

		String fileName;
		UUID uuid = UUID.randomUUID();
		
		if(profile.isEmpty()) {
			fileName = "-";
		}
		else {
			fileName = profile.getOriginalFilename();
			String fileName1 = uuid.toString() + fileName;
			mlVO.setUserProfile(fileName1);	
			try {
				// 실제 경로 images/userprofile
				String path = udir;
				File targetFile = new File(path, fileName1);
				
				profile.transferTo(targetFile);
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}
		// 일반 가입 유저 정보 가져오기
		String userid = user.getUserId();
		mlVO.setUserId(userid);
		
		// 토큰값 유무로 카카오 가입 유저인지 아닌지 판별
		if(access_token != null) {
			MuseLabVO userInfo = userService.getUserInfo(access_token);
			String kakaoid = userInfo.getKakaoId();
			mlVO.setUserId(kakaoid);
			
			int result = 0;
			result = userService.userProfileMod(mlVO);
			
			ModelAndView mav = new ModelAndView("redirect:/user/userInfo.do");
			return mav;
		}
		
		int result = 0;
		result = userService.userProfileMod(mlVO);
		
		ModelAndView mav = new ModelAndView("redirect:/user/userInfo.do");
		mav.addObject("userId",userid);
		return mav;
	}
	
	// form으로 끝나는 파일 실행시
	@GetMapping("/*Form.do")
	private ModelAndView form(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "action", required = false) String action, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String viewName = (String) request.getAttribute("viewName");
		HttpSession session = request.getSession();
		session.setAttribute("action", action);

		ModelAndView mav = new ModelAndView();
		mav.addObject("result", result);
		mav.setViewName(viewName);
		return mav;
	}
	
}
