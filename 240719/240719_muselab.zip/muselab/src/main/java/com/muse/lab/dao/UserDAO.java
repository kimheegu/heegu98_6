package com.muse.lab.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.muse.lab.vo.MuseLabVO;

@Mapper
@Repository("userDAO")
public interface UserDAO {
	// 회원 로그인
	public MuseLabVO userLogin(MuseLabVO mlVO) throws DataAccessException;
}
