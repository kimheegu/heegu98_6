package com.muse.lab.main;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component("mlVO")
public class MuseLabVO {
	// user
	private String userId;
	private String userPwd;
	private String userPhone;
	private String userEmail;
	private String userNickname;
	private String userProfile;
	private String userInfo;
	private String userAddress;
	private String userGrade;
	
	// music
	private int musicId;
	private String musicTitle;
	private String musicInfo;
	private String musicGenre;
	private String musicAlbum;
	private Date musicDate;
	private String musicImage;
	private int musicViews;
	private int musicLike;
	
	// music comment
	private int musicCommentId;
	private String musicCommentContent;
	private Date musicCommentDate;
	
	// music like
	private int musicLikeId;
	
	// playlist
	private int playlistId;
	private String playlistFolder;
	
	// community
	private int communityId;
	private String communityCategory;
	private String communityTitle;
	private String communityContent;
	private Date communityDate;
	private String communityImage1;
	private String communityImage2;
	private String communityImage3;
	private String communityImage4;
	private String communityImage5;
	private String communityViews;
	private String communityLike;
	
	// comm comment
	private int commCommentId;
	private String commCommentContent;
	private Date commCommentDate;
	
	// comm like
	private int commLikeID;
	
	// market
	private int marketId;
	private String marketTitle;
	private String marketContent;
	private String marketImage1;
	private String marketImage2;
	private String marketImage3;
	private String marketImage4;
	private String marketImage5;
	private int marketPrice;
	private String marketCondition;
	private String marketCategory;
	private String marketViews;
	private String marketLike;
	
	// market comment
	private int mkCommentId;
	private String mkCommentContent;
	private Date mkCommentDate;
	
	// market like
	private int mkLikeId;
	
	// user msg
	private int userMsgId;
	private String userMsgTitle;
	private String userMsgContent;
	private Date userMsgDate;
	
	// notice
	private int noticeId;
	
	// operation
	private int operationId;
	
	
	// getter, setter

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserNickname() {
		return userNickname;
	}

	public void setUserNickname(String userNickname) {
		this.userNickname = userNickname;
	}

	public String getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(String userProfile) {
		this.userProfile = userProfile;
	}

	public String getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(String userInfo) {
		this.userInfo = userInfo;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserGrade() {
		return userGrade;
	}

	public void setUserGrade(String userGrade) {
		this.userGrade = userGrade;
	}

	public int getMusicId() {
		return musicId;
	}

	public void setMusicId(int musicId) {
		this.musicId = musicId;
	}

	public String getMusicTitle() {
		return musicTitle;
	}

	public void setMusicTitle(String musicTitle) {
		this.musicTitle = musicTitle;
	}

	public String getMusicInfo() {
		return musicInfo;
	}

	public void setMusicInfo(String musicInfo) {
		this.musicInfo = musicInfo;
	}

	public String getMusicGenre() {
		return musicGenre;
	}

	public void setMusicGenre(String musicGenre) {
		this.musicGenre = musicGenre;
	}

	public String getMusicAlbum() {
		return musicAlbum;
	}

	public void setMusicAlbum(String musicAlbum) {
		this.musicAlbum = musicAlbum;
	}

	public Date getMusicDate() {
		return musicDate;
	}

	public void setMusicDate(Date musicDate) {
		this.musicDate = musicDate;
	}

	public String getMusicImage() {
		return musicImage;
	}

	public void setMusicImage(String musicImage) {
		this.musicImage = musicImage;
	}

	public int getMusicViews() {
		return musicViews;
	}

	public void setMusicViews(int musicViews) {
		this.musicViews = musicViews;
	}

	public int getMusicLike() {
		return musicLike;
	}

	public void setMusicLike(int musicLike) {
		this.musicLike = musicLike;
	}

	public int getMusicCommentId() {
		return musicCommentId;
	}

	public void setMusicCommentId(int musicCommentId) {
		this.musicCommentId = musicCommentId;
	}

	public String getMusicCommentContent() {
		return musicCommentContent;
	}

	public void setMusicCommentContent(String musicCommentContent) {
		this.musicCommentContent = musicCommentContent;
	}

	public Date getMusicCommentDate() {
		return musicCommentDate;
	}

	public void setMusicCommentDate(Date musicCommentDate) {
		this.musicCommentDate = musicCommentDate;
	}

	public int getMusicLikeId() {
		return musicLikeId;
	}

	public void setMusicLikeId(int musicLikeId) {
		this.musicLikeId = musicLikeId;
	}

	public int getPlaylistId() {
		return playlistId;
	}

	public void setPlaylistId(int playlistId) {
		this.playlistId = playlistId;
	}

	public String getPlaylistFolder() {
		return playlistFolder;
	}

	public void setPlaylistFolder(String playlistFolder) {
		this.playlistFolder = playlistFolder;
	}

	public int getCommunityId() {
		return communityId;
	}

	public void setCommunityId(int communityId) {
		this.communityId = communityId;
	}

	public String getCommunityCategory() {
		return communityCategory;
	}

	public void setCommunityCategory(String communityCategory) {
		this.communityCategory = communityCategory;
	}

	public String getCommunityTitle() {
		return communityTitle;
	}

	public void setCommunityTitle(String communityTitle) {
		this.communityTitle = communityTitle;
	}

	public String getCommunityContent() {
		return communityContent;
	}

	public void setCommunityContent(String communityContent) {
		this.communityContent = communityContent;
	}

	public Date getCommunityDate() {
		return communityDate;
	}

	public void setCommunityDate(Date communityDate) {
		this.communityDate = communityDate;
	}

	public String getCommunityImage1() {
		return communityImage1;
	}

	public void setCommunityImage1(String communityImage1) {
		this.communityImage1 = communityImage1;
	}

	public String getCommunityImage2() {
		return communityImage2;
	}

	public void setCommunityImage2(String communityImage2) {
		this.communityImage2 = communityImage2;
	}

	public String getCommunityImage3() {
		return communityImage3;
	}

	public void setCommunityImage3(String communityImage3) {
		this.communityImage3 = communityImage3;
	}

	public String getCommunityImage4() {
		return communityImage4;
	}

	public void setCommunityImage4(String communityImage4) {
		this.communityImage4 = communityImage4;
	}

	public String getCommunityImage5() {
		return communityImage5;
	}

	public void setCommunityImage5(String communityImage5) {
		this.communityImage5 = communityImage5;
	}

	public String getCommunityViews() {
		return communityViews;
	}

	public void setCommunityViews(String communityViews) {
		this.communityViews = communityViews;
	}

	public String getCommunityLike() {
		return communityLike;
	}

	public void setCommunityLike(String communityLike) {
		this.communityLike = communityLike;
	}

	public int getCommCommentId() {
		return commCommentId;
	}

	public void setCommCommentId(int commCommentId) {
		this.commCommentId = commCommentId;
	}

	public String getCommCommentContent() {
		return commCommentContent;
	}

	public void setCommCommentContent(String commCommentContent) {
		this.commCommentContent = commCommentContent;
	}

	public Date getCommCommentDate() {
		return commCommentDate;
	}

	public void setCommCommentDate(Date commCommentDate) {
		this.commCommentDate = commCommentDate;
	}

	public int getCommLikeID() {
		return commLikeID;
	}

	public void setCommLikeID(int commLikeID) {
		this.commLikeID = commLikeID;
	}

	public int getMarketId() {
		return marketId;
	}

	public void setMarketId(int marketId) {
		this.marketId = marketId;
	}

	public String getMarketTitle() {
		return marketTitle;
	}

	public void setMarketTitle(String marketTitle) {
		this.marketTitle = marketTitle;
	}

	public String getMarketContent() {
		return marketContent;
	}

	public void setMarketContent(String marketContent) {
		this.marketContent = marketContent;
	}

	public String getMarketImage1() {
		return marketImage1;
	}

	public void setMarketImage1(String marketImage1) {
		this.marketImage1 = marketImage1;
	}

	public String getMarketImage2() {
		return marketImage2;
	}

	public void setMarketImage2(String marketImage2) {
		this.marketImage2 = marketImage2;
	}

	public String getMarketImage3() {
		return marketImage3;
	}

	public void setMarketImage3(String marketImage3) {
		this.marketImage3 = marketImage3;
	}

	public String getMarketImage4() {
		return marketImage4;
	}

	public void setMarketImage4(String marketImage4) {
		this.marketImage4 = marketImage4;
	}

	public String getMarketImage5() {
		return marketImage5;
	}

	public void setMarketImage5(String marketImage5) {
		this.marketImage5 = marketImage5;
	}

	public int getMarketPrice() {
		return marketPrice;
	}

	public void setMarketPrice(int marketPrice) {
		this.marketPrice = marketPrice;
	}

	public String getMarketCondition() {
		return marketCondition;
	}

	public void setMarketCondition(String marketCondition) {
		this.marketCondition = marketCondition;
	}

	public String getMarketCategory() {
		return marketCategory;
	}

	public void setMarketCategory(String marketCategory) {
		this.marketCategory = marketCategory;
	}

	public String getMarketViews() {
		return marketViews;
	}

	public void setMarketViews(String marketViews) {
		this.marketViews = marketViews;
	}

	public String getMarketLike() {
		return marketLike;
	}

	public void setMarketLike(String marketLike) {
		this.marketLike = marketLike;
	}

	public int getMkCommentId() {
		return mkCommentId;
	}

	public void setMkCommentId(int mkCommentId) {
		this.mkCommentId = mkCommentId;
	}

	public String getMkCommentContent() {
		return mkCommentContent;
	}

	public void setMkCommentContent(String mkCommentContent) {
		this.mkCommentContent = mkCommentContent;
	}

	public Date getMkCommentDate() {
		return mkCommentDate;
	}

	public void setMkCommentDate(Date mkCommentDate) {
		this.mkCommentDate = mkCommentDate;
	}

	public int getMkLikeId() {
		return mkLikeId;
	}

	public void setMkLikeId(int mkLikeId) {
		this.mkLikeId = mkLikeId;
	}

	public int getUserMsgId() {
		return userMsgId;
	}

	public void setUserMsgId(int userMsgId) {
		this.userMsgId = userMsgId;
	}

	public String getUserMsgTitle() {
		return userMsgTitle;
	}

	public void setUserMsgTitle(String userMsgTitle) {
		this.userMsgTitle = userMsgTitle;
	}

	public String getUserMsgContent() {
		return userMsgContent;
	}

	public void setUserMsgContent(String userMsgContent) {
		this.userMsgContent = userMsgContent;
	}

	public Date getUserMsgDate() {
		return userMsgDate;
	}

	public void setUserMsgDate(Date userMsgDate) {
		this.userMsgDate = userMsgDate;
	}

	public int getNoticeId() {
		return noticeId;
	}

	public void setNoticeId(int noticeId) {
		this.noticeId = noticeId;
	}

	public int getOperationId() {
		return operationId;
	}

	public void setOperationId(int operationId) {
		this.operationId = operationId;
	}
	
	
} 
